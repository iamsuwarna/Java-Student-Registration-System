//Creation of child class
public class NonAcademicCourse extends course{
    private String Instructor_Name;
    private int Duration;
    private String Starting_Date;
    private String Completion_Date;
    private String Exam_Date;
    private String Prequistie;
    private boolean isregistered;
    private boolean isremoved;
    
    //Production of constructor which have parameters within it
    public NonAcademicCourse(String courseID , String coursename ,int duration , String Prequistie){
    super(courseID ,coursename , duration);
    this.Starting_Date ="";
    this. Completion_Date ="";
    this.Exam_Date = "";
    this.isregistered = false;
    this.isremoved= false;
    this.Duration = duration;
    this.Prequistie = Prequistie;
    }
    
    //Generation of a method "call" which calls variables from its parent class.
    public void call(String courseID , String coursename , int duration)
    {
        super.courseID = courseID;
        super.coursename = coursename;
        super.duration = duration;
    }
    
    //Initialization of getter methods 
     public String getIns_name(){
        return this.Instructor_Name;
    }
     public int getduration(){
        return this.Duration;
    }
     public String getS_date(){
        return this.Starting_Date;
    }
     public String getComp_date(){
        return this.Completion_Date;
    }
     public String getE_Date(){
        return this.Exam_Date;
    }
     public String getpresquistie(){
        return this.Prequistie;
    }
     public boolean getis_registered(){
        return this.isregistered ;
    }
    public boolean getis_removed(){
        return this.isremoved;
    }
    
    //Initialization of setter method
    public void setInstructor_name(String Inst_name){
        if(this.isregistered){
            System.out.println("As the Non Academic Course is already registered , now the Instructor's name cannot be changed");
            this.Instructor_Name = Inst_name;
        }
        else{
            this.Instructor_Name = Inst_name;
        }   
    }
    
    //A method named "register" is constructed with parameters in it
    public void register(String courseleader , String Instructor_Name , String Starting_Date  , String Completion_Date , String Exam_Date){
        this.courseleader = courseleader;
        this.Instructor_Name = Instructor_Name;
        this.Starting_Date =Starting_Date;
        this.Completion_Date= Completion_Date;
        this.Exam_Date =Exam_Date;
        if(this.isregistered == true){
            System.out.println("The Non Academic Course is already registered");
            super.setleader(courseleader);

        }
        else{
            setInstructor_name(Instructor_Name);
            this.isregistered = true;
        }
    }
    
    //Construction of a method "remove" with If-Else statementts within it 
    public void remove(){
        if(isremoved == true){
           System.out.println("The Non Academic Course is already removed");
        }
        else{
            super.setleader(courseleader);
            this.Instructor_Name = "";
            this.Starting_Date = "";
            this.Completion_Date =""; 
            this.Exam_Date = "";
        }
        this.isregistered = true;
        this.isremoved = true ;
        } 
        
    //Production of a method "displau" Which displays all the output of this class
    public void display(){
        super.display();
        if(isregistered == true){
            System.out.println("The Instructor of this Non-Academic Course is Mr." + Instructor_Name +".");
            System.out.println("This Non-Academic course was started on " + Starting_Date + "." );
            System.out.println("This respective Non-Academic course was complete on " + Completion_Date + ".");
            System.out.println("The Examination date of this course was " + Exam_Date + "." );
        }
    }
}