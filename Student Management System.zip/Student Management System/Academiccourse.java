//Production of child class
public class Academiccourse extends course
{
    private String Lecturer_Name;
    private String Level;
    private String credit;
    private String Starting_Date;
    private String Completion_Date;
    private int Number_of_Assessments;
    private boolean is_registered;
    
    //Creation of a parameterized constructor
    public Academiccourse(String courseID , String coursename , int duration , String Level , String credit , int Number_of_Assessments){
        super(courseID , coursename , duration);
        this.Lecturer_Name = Lecturer_Name;
        this.Starting_Date =Starting_Date;
        this.Completion_Date = "";
        this.is_registered =false;
        this.Level =Level;
        this.credit = credit;
        this.Number_of_Assessments =Number_of_Assessments;
        super.courseID = courseID;
        super.coursename= coursename;
        super.duration = duration;
    }
    
    //Intialization of method"call" to call data from its parent class
    public void call(String courseId , String coursename , int duration){
        super.courseID = courseID;
        super.coursename = coursename;
        super.duration = duration;
        
    }
    
    //Application of getter methods
    public String getname(){
        return this.Lecturer_Name;
    }
    public int getassessments(){
        return this.Number_of_Assessments;
    }
    public String getlevel(){
        return this.Level;
    }
    public String getStart_date(){
        return this.Starting_Date;
    }
    public String getComplete_date(){
    return this.Completion_Date; 
    }
    public boolean getregistery(){
    return this.is_registered;
    }
    
    //Application of setter methods 
    public void setLecturername(String Lect_name){
        this.Lecturer_Name = Lect_name;
    }
    public void setassessments(int assessments){
     this.Number_of_Assessments = assessments;
    }
    
    //Creation of method "register" with parameters in it
    public void register(String courseleader , String Lecturer_name , String Starting_Date , String Completion_Date)
    {
        if(this.is_registered){
            System.out.println("The starting date of this Academic Course was " + this.Starting_Date);
            System.out.println("The completion date of this Academic Course was " + this.Completion_Date);
            System.out.println("The Instructor  of this Academic Course is Mr. " + this.Lecturer_Name);
        }
        else{
            super.setleader(courseleader);
            this.courseleader = courseleader;
            this.Lecturer_Name = Lecturer_name;
            this.Starting_Date = Starting_Date;
            this.Completion_Date = Completion_Date;
        }
        this.is_registered = true;        
    }
    
    //Intialization of display method to display the output of this course
    public void display(){
        super.display();
        System.out.println("The lecturer of the course 'Argumented Reality' is Mr. " + Lecturer_Name +".");
        System.out.println("This course is taught on " + Level +" level.");
        System.out.println("This Academic Course has total credit of " + credit+ ".");
        System.out.println("This course was started on " + Starting_Date + ".");
        System.out.println("This respective course was completed on " + Completion_Date + ".");
        System.out.println(Number_of_Assessments + " total Assessments were given in this course.");
        System.out.println("It is " + is_registered + " that , this course has been registered as one of the most valuable course of this generation." );
        if(is_registered){
            System.out.println("The starting date of this Academic Course was " + Starting_Date);
            System.out.println("The completion date of this Academic Course was " + Completion_Date);
            System.out.println("The Instructor of this Academic Course is Mr. " + Lecturer_Name);
            
        }
        else{
            System.out.println("The Academic Course is not registered");
        }
    } 
        }
               
    
    
     
    
    
    
        
    
        
            
    
   