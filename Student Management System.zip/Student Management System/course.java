//Creation of parent class
public class course{
    //Declartion of private Datatypes
    protected String courseID;
    protected String coursename;
    protected String courseleader;
    protected int duration;
    
    //Intializing constructor with parameters
    public course(String courseID , String coursename , int duration)
    {
        this.courseID = courseID;
        this.coursename =coursename;
        this.duration =duration; 
        this.courseleader =""; 
    }
    
    //Application of accessor method 
    public String getid()
    {
        return this.courseID;
    }
    public String getcname()
    {
        return this.coursename;
    }
    public int getduration()
    {
        return this.duration;
    }
    
    //Application of mutator method 
    public void setleader(String leader_name)
    {
        this.courseleader = leader_name;
    }
    public String getLname(){
        return courseleader;
    }
    
    //Creation of Display Method 
    public void display()
    {
        System.out.println("The name of the course is " + coursename+".");
        System.out.println("The duration of the course is " + duration + " months.");
        System.out.println("The course id of Argumented Reality is " +courseID + ".");
        if(this.courseleader !=""){
            System.out.println("The name of the courseleader is " + this.courseleader + ".");  
        }
        else{
            System.out.println("The name of the courseleader is not given.");
        }
        }
     }
    
    
